from pathlib import Path
import subprocess
base=Path('.superpowers/sdd/2026-10-16-m1-owner-contracts')
cases=[('selected-omission','src/lifecycle/upsert.rs','if !changed.contains(&old.installation_id) {','if true {','upsert_replaces_explicit_proof_and_preserves_untouched_contracts'),('retained-proof','src/lifecycle/retire/mod.rs','.retain(|c| !retired.contains(c.installation_id.as_str()));','.retain(|_| false);','shared_retirement_keeps_survivor_proof_until_final_owner_retires'),('retired-proof','src/lifecycle/retire/mod.rs','.retain(|c| !retired.contains(c.installation_id.as_str()));','.retain(|_| true);','shared_retirement_keeps_survivor_proof_until_final_owner_retires'),('canonical-contracts','src/lifecycle/state/codec.rs','ordered\n        .owner_contracts\n        .sort_by_key(super::super::contracts::key);','','deterministic_codec_sorts_contracts_and_profiles_without_inference')]
for name,path,old,new,test in cases:
 p=Path(path);original=p.read_bytes();assert old in original.decode(),name
 try:
  p.write_text(original.decode().replace(old,new,1))
  r=subprocess.run(['cargo','test','--test','lifecycle_contracts',test],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  (base/f'control-{name}.log').write_bytes(r.stdout)
  assert r.returncode!=0 and b'panicked at' in r.stdout,(name,r.stdout.decode())
  print(name+': assertion-failing control',flush=True)
 finally:p.write_bytes(original)
