from pathlib import Path
import subprocess, hashlib, difflib, json
base=Path('.superpowers/sdd/2026-10-16-m1-owner-contracts')
C='src/lifecycle/contracts.rs';U='src/lifecycle/upsert.rs';R='src/lifecycle/retire/mod.rs';S='src/lifecycle/state/codec.rs'
cases=[
('unchanged-owner',U,'changed.contains(&contract.installation_id),','true,','unchanged_owner_cannot_gain_previously_absent_proof'),
('no-op-omission',U,'owner_contracts.push(contract);\n        }','owner_contracts.push(contract);\n        } else { owner_contracts.push(old.clone()); }','no_op_selected_update_clears_omitted_proof'),
('diagnostic-order',C,'for owner in &artifact.owners {','let mut owners = artifact.owners.clone(); owners.sort_by(|a,b| a.installation_id.cmp(&b.installation_id));\n    for owner in &owners {','agreement_reports_recorded_owner_order_and_validates_whole_state'),
('whole-state',C,'validate_state(state)?;','','agreement_reports_recorded_owner_order_and_validates_whole_state'),
('query-scope',C,'a.root.scope == root.scope','true','agreement_query_requires_exact_scope_and_raw_root'),
('query-raw-root',C,'a.root.path.as_os_str() == root.path.as_os_str()','true','agreement_query_requires_exact_scope_and_raw_root'),
('new-evidence',U,'owner_contracts.extend(supplied_contracts.into_values());','','previously_absent_evidence_appends_in_full_identity_order'),
('upsert-retirement',U,'if !changed.contains(&old.installation_id) {','if !request.sets.iter().any(|s| s.installation.owner.installation_id == old.installation_id) {','graph_retirement_clears_proof_without_a_desired_set'),
('profile-strict',C,'#[serde(deny_unknown_fields)]','','nested_contract_fields_reject_unknown_keys'),
('content-strict',C,'#[serde(tag = "kind", rename_all = "kebab-case", deny_unknown_fields)]','#[serde(tag = "kind", rename_all = "kebab-case")]','nested_contract_fields_reject_unknown_keys'),
('codec-path-order',S,'.sort_by_key(super::super::contracts::key);','.sort_by_key(|c| c.installation_id.clone());','canonical_contract_order_uses_path_before_owner'),
('codec-complete',S,'let mut json =','ordered.owner_contracts.truncate(1);\n    let mut json =','codec_preserves_every_contract_and_profile'),
]
receipts=[]
for name,path,old,new,test in cases:
 p=Path(path);original=p.read_bytes();text=original.decode();assert old in text,name
 mutated=text.replace(old,new,1)
 (base/f'control-{name}.patch.txt').write_text(''.join(difflib.unified_diff(text.splitlines(True),mutated.splitlines(True),fromfile=path,tofile=path)))
 try:
  p.write_text(mutated)
  r=subprocess.run(['cargo','test','--test','lifecycle_contracts',test],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  (base/f'control-{name}.log').write_bytes(r.stdout)
  assert r.returncode!=0 and b'panicked at' in r.stdout,(name,r.stdout.decode())
 finally:p.write_bytes(original)
 assert p.read_bytes()==original
 receipts.append({'control':name,'test':test,'exit_code':r.returncode,'assertion_failure':True,'before_sha256':hashlib.sha256(original).hexdigest(),'after_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 print(name+': assertion-failing control, exact restoration',flush=True)
(base/'review-control-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
