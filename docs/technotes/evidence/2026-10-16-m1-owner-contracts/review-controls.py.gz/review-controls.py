from pathlib import Path
import subprocess
base=Path('.superpowers/sdd/2026-10-16-m1-owner-contracts')
cases=[('partial-missing','src/lifecycle/contracts.rs','issue: ContractIssue::MissingEvidence,\n            });','issue: ContractIssue::MissingEvidence,\n            });\n            if baseline.is_some() { conflicts.pop(); }','missing_later_owner_blocks_even_after_recorded_baseline'),('rule-only','src/lifecycle/contracts.rs','installation.owner.kind == ItemKind::Rule','true','non_rule_owners_remain_representable_without_contract_evidence'),('preserve-order','src/lifecycle/upsert.rs','owner_contracts.extend(supplied_contracts.into_values());','owner_contracts.extend(supplied_contracts.into_values());\n    owner_contracts.sort_by_key(super::contracts::key);','replacement_preserves_prior_contract_positions')]
for name,path,old,new,test in cases:
 p=Path(path);original=p.read_bytes();assert old in original.decode(),name
 try:
  p.write_text(original.decode().replace(old,new,1))
  r=subprocess.run(['cargo','test','--test','lifecycle_contracts',test],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  (base/f'control-{name}.log').write_bytes(r.stdout)
  assert r.returncode!=0 and b'panicked at' in r.stdout,(name,r.stdout.decode())
  print(name+': assertion-failing control',flush=True)
 finally: p.write_bytes(original)
