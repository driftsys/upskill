from pathlib import Path
import subprocess
base=Path('.superpowers/sdd/2026-10-16-m1-owner-contracts')
p=Path('src/lifecycle/contracts.rs')
original=p.read_bytes()
cases=[
('missing', 'conflicts.push(ContractConflict {installation_id:id.clone(),issue:ContractIssue::MissingEvidence});continue;', 'continue;', 'absent_historical_evidence_is_not_inferred_or_serialized'),
('source', 'reference.source_manifest_sha256!=c.source_manifest_sha256', 'false', 'same_output_does_not_hide_source_or_profile_disagreement'),
('profile', 'profiles(reference)!=profiles(c)', 'false', 'profile_order_is_irrelevant_and_all_disagreements_are_reported'),
('content', 'content(&artifact.content)==c.content', 'true', 'present_contracts_require_exact_binding_source_content_and_profiles'),
('revision', 'p.contract_revision>0', 'p.contract_revision>=0', 'present_contracts_require_exact_binding_source_content_and_profiles'),
('source_binding', 'source==&c.source_manifest_sha256', 'true', 'present_contracts_require_exact_binding_source_content_and_profiles'),
]
try:
 for name,old,new,test in cases:
  text=original.decode(); assert old in text,name
  p.write_text(text.replace(old,new,1))
  result=subprocess.run(['cargo','test','--test','lifecycle_contracts',test],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  (base/f'control-{name}.log').write_bytes(result.stdout)
  assert result.returncode!=0 and b'panicked at' in result.stdout,(name,result.stdout.decode())
  print(name+': assertion-failing control',flush=True)
  p.write_bytes(original)
finally:
 p.write_bytes(original)
