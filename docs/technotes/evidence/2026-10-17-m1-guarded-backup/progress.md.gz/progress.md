# SDD ledger — plan: docs/wip/plans/2026-10-17-m1-guarded-backup.md

Base f54c457a30473511b66349ab4d95f30ae62d654b. User resumed Gate5; prior ledger
explicitly delegated decisions and native inline execution. Live #295–#302
merged; origin/main refreshed and clean. New isolated feat/m1-gate5-application,
bootstrap exit0. Baseline cargo test --locked exit0 (log
/private/tmp/upskill-gate5-application-baseline.log). Ruling: scope the next
delivery slice to exact guarded backup within the existing executor — the
accepted Gate5 design requires this prerequisite before lifecycle application —
cost if wrong: another bounded integration PR is necessary. Ruling: use existing
rustix renameat_with NOREPLACE on Linux/macOS — atomic exclusive publication
prevents late-arrival overwrite without hard-link crash windows — cost if wrong:
unsupported filesystem rename flags fail closed. Ruling: backup journal uses
execution-journal schema2; original schema1 execution remains unchanged —
schema2 requires exactly one create-only first action bound to final State
before bytes, so removing the flag cannot silently convert backup to replacement
— cost if wrong: older binaries reject backup journals until upgraded. Ruling:
accept any caller-authorized original state bytes rather than parse schema1 JSON
in the generic executor — lifecycle preparation must validate its own state
transition — cost if wrong: this primitive alone does not establish schema2
lifecycle correctness. Preflight: prepared backup passes shared request topology
checks; entire source/destination preflight precedes store creation; journal
flag must survive persistence and recovery; unchanged backups need file and
directory sync before Done. Existing executor callers and source-compatible
ExecutionRequest remain unchanged. Task1 acceptance RED: missing entrypoint
compile error, then forwarding old executor assertion-failed on no backup/action
prefix, ignored mismatches and aliases. GREEN five integration tests. Logs
/private/tmp/upskill-gate5-backup-{red,behavior-red,green}.log. Task1
implementation: prepend exact original bytes mode0600; reject existing mismatch;
journal schema2 persists create_only and validates index/state/before/after
binding; NOREPLACE publication; existing exact backup receives durable post-sync
before receipt. Internal tests cover late arrival, completed-backup edit,
corrupt flag/evidence/mode and existing-backup sync. Process kill coverage in
progress.
Independent whole-change review: no Critical/Important/Minor findings; no duplicate tests. Ruling: lifecycle validation/ownership/observational adapters remain outside this generic primitive — accepted bounded contract — cost if wrong: subsequent integration must still supply these gates. Ruling: journal authentication against coordinated malicious rewriting is not added — existing journals have structural/payload binding, not authentication — cost if wrong: untrusted writers with scope write access remain outside threat model. Ruling: advisory-lock namespace limitations and no hardware power-loss claim stand — existing protocol and process evidence — cost if wrong: unsupported external interference requires reconciliation. Hosted and MSRV claims require actual verification; local MSRV exit0.
Controls: NOREPLACE changed to empty flags, mandatory create-only ordering removed, matching-backup sync skipped; all three compile and assertion-fail exit101. Exact source restored, focused4/4 green. Full justverify Rust suites passed; docs-check failed on new local technote links; fixed root cause by using repository URLs for non-book evidence. Final gate pending gardening.
Gardening: AD0037 created, AD0033/index/design reconciled; exact bounded pair archived; foreign34 WIP remain active untouched. Original rawspec SHA1a33e9cf restored after broad formatter rewrapped it; narrow .primignore exception added. Original rawplan SHAe59a4815 unchanged. No project-policy drift or deferred findings. Final full gate running after corrected book links.
Task1 complete: final justverify exit0,1252 Rust tests/0fail/1ignored, docs/book/schema/link checks and build passed. justfmt exit0; clippy/MSRV1.85 exit0. All new runtime source hashes match restored controls. Independent review no findings. Second docs-only attempt required creating retained manifest and including newADR in bookSUMMARY; targeted docscheck and final full justverify now pass. Final evidence, commit and hosted delivery follow.
