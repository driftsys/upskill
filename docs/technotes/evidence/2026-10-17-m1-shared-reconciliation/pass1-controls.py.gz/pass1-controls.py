from pathlib import Path
import subprocess,json
scratch=Path(__file__).parent
controls=[
 ('producer-completeness','src/lifecycle/desired/contracts.rs','for artifact in &set.artifacts {','for artifact in set.artifacts.iter().take(2) {','lifecycle_contract_producer'),
 ('known-release-proof','src/lifecycle/sharing/mod.rs','    candidate.artifacts = rebuilt.artifacts;','    candidate.artifacts = rebuilt.artifacts;\n    if changes.iter().all(|v| matches!(v, InstallationChange::Remove {..})) { candidate.owner_contracts.clear(); }','lifecycle_sharing'),
 ('varied-consumers','src/lifecycle/sharing/artifacts.rs','    row.consumers = consumers.into_values().collect();','    row.consumers = vec![crate::target::TargetSurface::ClaudeCli];','lifecycle_sharing'),
 ('git-revision','src/lifecycle/sharing/artifacts.rs','                row.owners.push(replacement);','                let _ = replacement; row.owners.push(owner.clone());','lifecycle_sharing'),
 ('diagnostic-owner-filter','src/lifecycle/sharing/physical.rs','.filter(|a| owned_key(a) == *key)', '.filter(|_| true)', 'lifecycle_sharing'),
]
receipts=[]
for name,file,a,b,target in controls:
 p=Path(file);old=p.read_bytes();text=old.decode();assert a in text,name
 try:
  p.write_text(text.replace(a,b));r=subprocess.run(['cargo','test','--test',target],capture_output=True,text=True);out=r.stdout+r.stderr;(scratch/('pass1-control-'+name+'.log')).write_text(out)
  assert r.returncode and 'panicked at' in out,(name,out[-1000:]);print(name,'assertion RED');receipts.append({'name':name,'exit':r.returncode,'assertion_failure':True})
 finally:p.write_bytes(old)
(scratch/'pass1-controls.json').write_text(json.dumps(receipts,indent=2)+'\n')
