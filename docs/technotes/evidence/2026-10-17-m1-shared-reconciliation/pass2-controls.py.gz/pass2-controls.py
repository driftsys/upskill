from pathlib import Path
import subprocess,json
scratch=Path(__file__).parent;p=Path('src/lifecycle/sharing/physical.rs');receipts=[]
for name in ['missing-file','mode-file','retained-root','retained-scope','retained-fields','instruction-absence-utf8']:
 old=p.read_bytes();s=old.decode()
 if name=='missing-file':s=s.replace('"missing owned file",','"ignored missing owned file",')
 elif name=='mode-file':s=s.replace('"owned file mode evidence changed",','"ignored owned file mode evidence changed",')
 elif name in ['retained-root','retained-scope']:
  a=s.index('fn real_context(');prefix=s[:a];body=s[a:];needle='a.root.path.as_os_str() == row.root.path.as_os_str()' if name=='retained-root' else 'a.root.scope == row.root.scope';assert needle in body;body=body.replace(needle,'true');s=prefix+body
 elif name=='retained-fields':
  a=s.index('fn real_context(');b=s.rfind('    format!(');assert b>a;s=s[:b]+'    format!("physical file {} ({ownership})",row.path)\n}\n'
 else:
  needle='    if let Some(context) = error.downcast_ref::<InstructionFileContext>() {';assert needle in s
  s=s.replace(needle,'    if !format!("{error:#}").contains("invalid UTF-8") && !format!("{error:#}").contains("is absent") {\n'+needle)
  s=s.replace('    let message = error\n','    }\n    let message = error\n')
 assert s!=old.decode(),name
 try:
  p.write_text(s);r=subprocess.run(['cargo','test','--test','lifecycle_sharing'],capture_output=True,text=True);out=r.stdout+r.stderr;(scratch/('pass2-control-'+name+'.log')).write_text(out);assert r.returncode and 'panicked at' in out,(name,out[-800:]);print(name,'assertion RED');receipts.append({'name':name,'exit':r.returncode,'assertion_failure':True})
 finally:p.write_bytes(old)
(scratch/'pass2-controls.json').write_text(json.dumps(receipts,indent=2)+'\n')
